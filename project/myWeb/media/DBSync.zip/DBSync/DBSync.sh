script_dir_path=$(dirname $(readlink -f $0))
cd $script_dir_path;

java -jar DBSync.jar 1 
java -jar DBSync.jar 2 
java -jar DBSync.jar 3 
